# YOLOv3 (detection only) #

This is a work in progress. Only detection with YOLOv3 is supported at the moment. Get the pretrained weights from https://pjreddie.com/media/files/yolov3.weights.

```python yolo3_detect.py -w yolov3.weights -i dog.jpg``` 
