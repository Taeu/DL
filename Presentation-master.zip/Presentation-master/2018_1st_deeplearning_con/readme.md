2018 1st 딥러닝 컨퍼런스 





# 슈퍼마리오 환경 설치 메뉴얼 및 튜토리얼

https://github.com/wonseokjung/moduyeon_supermario

# Sonic 환경 설치 메뉴얼

https://wonseokjung.github.io//openairetro/update/Retro-1/


# 발표 자료

slide share 

https://www.slideshare.net/wonseokjung2/running-ai-103298468

# 구현 nb viewer version

http://nbviewer.jupyter.org/gist/wonseokjung/376d8a34b93e0d65783e9965c76eb5fe

